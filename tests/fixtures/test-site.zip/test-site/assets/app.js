// Simple test app
console.log('App loaded');

document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM ready');
});
